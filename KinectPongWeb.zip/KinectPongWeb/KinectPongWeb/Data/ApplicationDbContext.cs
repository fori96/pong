﻿using System;
using System.Collections.Generic;
using System.Text;
using KinectPongWeb.Areas.Identity.Data;
using KinectPongWeb.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace KinectPongWeb.Data
{
    public partial class ApplicationDbContext : IdentityDbContext<KinectPongWebUser, ApplicationRole, string,
        ApplicationUserClaim, ApplicationUserRole, ApplicationUserLogin,
        ApplicationRoleClaim, ApplicationUserToken>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public string ConnectionString { get; set; }

        public ApplicationDbContext(string connectionString)
        {
            this.ConnectionString = connectionString;
        }

        //public DbSet<Player> Players { get; set; }
        public DbSet<KinectPongWebUser> Players { get; set; }
        public DbSet<Game> Games { get; set; }
        public DbSet<ResztvettJatek> ResztvettJateks {get; set;}

    }
}
