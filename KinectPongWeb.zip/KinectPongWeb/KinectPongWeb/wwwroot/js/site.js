﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your Javascript code.

function submit() {
    var p1 = document.getElementById('CurrentScore').innerHTML;
    var p2 = document.getElementById('HighScore').innerHTML;

    if (p1 > p2)
        document.getElementById('HighScore').innerHTML = p1;
}
