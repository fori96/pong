
// Global Variables
var DIRECTION = {
	IDLE: 0,
	UP: 1,
	DOWN: 2,
	LEFT: 3,
	RIGHT: 4
};

var rounds = [5, 5, 3, 3, 2];
var colors = ['#1abc9c', '#2ecc71', '#3498db', '#e74c3c', '#9b59b6'];
var distance = 60000;
var team1score= 0;
var team2score= 0;

// The ball object (The cube that bounces back and forth)
var Ball = {
	new: function (incrementedSpeed) {
		return {
			width: 18,
			height: 18,
			x: (this.canvas.width / 2) - 9,
			y: (this.canvas.height / 2) - 9,
			moveX: DIRECTION.IDLE,
			moveY: DIRECTION.IDLE,
			speed: incrementedSpeed || 9
		};
	}
};

// The player object (The two lines that move up and down)
//horizontal
var hPaddle = {
	new: function (side) {
		return {
			width: 18,
			height: 70,
			x: side === 'left' ? 150 : this.canvas.width - 150,
			y: (this.canvas.height / 2) - 35,
			score: 0,
			move: DIRECTION.IDLE,
			speed: 10
		};
	}
};
//vertical
var vPaddle = {
	new: function (side) {
		return {
			width: 70,
			height: 18,
			y: side === 'top' ? 150 : this.canvas.height - 150,
			x: (this.canvas.width/ 2) - 35,
			score: 0,
			move: DIRECTION.IDLE,
			speed: 10
		};
	}
};

var Game2 = {
	initialize: function () {
		this.canvas = document.getElementById('c1');
		// this.panel = document.getElementById('hey');
		this.context = this.canvas.getContext('2d');

		this.canvas.width = 1370;
		this.canvas.height = 1000;

		this.canvas.style.width = (this.canvas.width / 2) + 'px';
		this.canvas.style.height = (this.canvas.height / 2) + 'px';

		this.player1 = hPaddle.new.call(this, 'left');
		this.player2 = hPaddle.new.call(this, 'right');
		
		/////////
		this.player3 = vPaddle.new.call(this, 'top');
		this.player4 = vPaddle.new.call(this, 'bottom');
		/////////
		
		this.ball = Ball.new.call(this);

		this.player2.speed = 8;
		this.running = this.over = false;
		this.turn = this.player2;
		this.timer = this.round = 0;
		this.color = '#2c3e50';

		Pong2.menu();
		Pong2.listen();
	},

	endGameMenu: function (text) {
		// Change the canvas font size and color
		Pong2.context.font = '50px Courier New';
		Pong2.context.fillStyle = this.color;

		// Draw the rectangle behind the 'Press any key to begin' text.
		Pong2.context.fillRect(
			Pong2.canvas.width / 2 - 350,
			Pong2.canvas.height / 2 - 48,
			700,
			100
		);

		// Change the canvas color;
		Pong2.context.fillStyle = '#ffffff';

		// Draw the end game menu text ('Game Over' and 'Winner')
		Pong2.context.fillText(text,
			Pong2.canvas.width / 2,
			Pong2.canvas.height / 2 + 15
		);

		setTimeout(function () {
			Pong2 = Object.assign({}, Game2);
			Pong2.initialize();
		}, 3000);
	},

	menu: function () {
		// Draw all the Pong2 objects in their current state
		Pong2.draw();

		// Change the canvas font size and color
		this.context.font = '50px Courier New';
		this.context.fillStyle = this.color;

		// Draw the rectangle behind the 'Press any key to begin' text.
		this.context.fillRect(
			this.canvas.width / 2 - 350,
			this.canvas.height / 2 - 48,
			700,
			100
		);

		// Change the canvas color;
		this.context.fillStyle = '#ffffff';

		// Draw the 'press any key to begin' text
		this.context.fillText('Press any key to begin',
			this.canvas.width / 2,
			this.canvas.height / 2 + 15
		);
	},

	// Update all objects (move the player1, player2, ball, increment the score, etc.)
	update: function () {
		if (!this.over) {
			// If the ball collides with the bound limits - correct the x and y coords.
			if (this.ball.x <= 0) Pong2._resetTurn.call(this, this.player2);
			if (this.ball.x >= this.canvas.width - this.ball.width) Pong2._resetTurn.call(this, this.player1);
			if (this.ball.y <= 0) Pong2._resetTurn.call(this, this.player4);
			if (this.ball.y >= this.canvas.height - this.ball.height) Pong2._resetTurn.call(this, this.player3);
			//ide kell a fenti lenti score ^^
			
			// Move player1 an p2 if they player1.move value was updated by a keyboard event
			if (this.player1.move === DIRECTION.UP) this.player1.y -= this.player1.speed;
			else if (this.player1.move === DIRECTION.DOWN) this.player1.y += this.player1.speed;
			
			if (this.player2.move === DIRECTION.UP) this.player2.y -= this.player2.speed;
			else if (this.player2.move === DIRECTION.DOWN) this.player2.y += this.player2.speed;
			
			//a vízszintes játékosok
			////////
			if (this.player3.move === DIRECTION.LEFT) this.player3.x -= this.player3.speed;
			else if (this.player3.move === DIRECTION.RIGHT) this.player3.x += this.player3.speed;
			
			if (this.player4.move === DIRECTION.LEFT) this.player4.x -= this.player4.speed;
			else if (this.player4.move === DIRECTION.RIGHT) this.player4.x += this.player4.speed;
			///////////
			

			// On new serve (start of each turn) move the ball to the correct side
			// and randomize the direction to add some challenge.
			if (Pong2._turnDelayIsOver.call(this) && this.turn) {
				this.ball.moveX = this.turn === this.player1 ? DIRECTION.LEFT : DIRECTION.RIGHT;
				this.ball.moveY = [DIRECTION.UP, DIRECTION.DOWN][Math.round(Math.random())];
				this.ball.y = Math.floor(Math.random() * this.canvas.height - 200) + 200;
				this.turn = null;
			}

			// If the player1 collides with the bound limits, update the x and y coords.
			if (this.player1.y <= 0) this.player1.y = 0;
			else if (this.player1.y >= (this.canvas.height - this.player1.height)) this.player1.y = (this.canvas.height - this.player1.height);
			
			if (this.player2.y <= 0) this.player2.y = 0;
			else if (this.player2.y >= (this.canvas.height - this.player2.height)) this.player2.y = (this.canvas.height - this.player2.height);
			
			//vízszintesek
			///////////
			if (this.player3.x <= 0) this.player3.x = 0;
			else if (this.player3.x >= (this.canvas.width - this.player3.width)) this.player3.x = (this.canvas.width - this.player3.width);
			
			if (this.player4.x <= 0) this.player4.x = 0;
			else if (this.player4.x >= (this.canvas.width - this.player4.width)) this.player4.x = (this.canvas.width - this.player4.width);
			///////////

			// Move ball in intended direction based on moveY and moveX values
			if (this.ball.moveY === DIRECTION.UP) this.ball.y -= (this.ball.speed / 1.5);
			else if (this.ball.moveY === DIRECTION.DOWN) this.ball.y += (this.ball.speed / 1.5);
			if (this.ball.moveX === DIRECTION.LEFT) this.ball.x -= this.ball.speed;
			else if (this.ball.moveX === DIRECTION.RIGHT) this.ball.x += this.ball.speed;


			// Handle player1-Ball collisions
			if (this.ball.x - this.ball.width <= this.player1.x && this.ball.x >= this.player1.x - this.player1.width) {
				if (this.ball.y <= this.player1.y + this.player1.height && this.ball.y + this.ball.height >= this.player1.y) {
					this.ball.x = (this.player1.x + this.ball.width);
					this.ball.moveX = DIRECTION.RIGHT;

				}
			}

			// Handle player2-ball collision
			if (this.ball.x - this.ball.width <= this.player2.x && this.ball.x >= this.player2.x - this.player2.width) {
				if (this.ball.y <= this.player2.y + this.player2.height && this.ball.y + this.ball.height >= this.player2.y) {
					this.ball.x = (this.player2.x - this.ball.width);
					this.ball.moveX = DIRECTION.LEFT;

				}
			}
			
			////////////////////////////////////////////////
			// Handle player3-ball collision
			if (this.ball.y - this.ball.height <= this.player3.y && this.ball.y >= this.player3.y - this.player3.height) {
				if (this.ball.x <= this.player3.x + this.player3.width && this.ball.x + this.ball.width >= this.player3.x) {
					this.ball.y = (this.player3.y + this.ball.height);
					this.ball.moveY = DIRECTION.DOWN;

				}
			}
			
			// Handle player4-ball collision
			if (this.ball.y - this.ball.height <= this.player4.y && this.ball.y >= this.player4.y - this.player4.height) {
				if (this.ball.x <= this.player4.x + this.player4.width && this.ball.x + this.ball.width >= this.player4.x) {
					this.ball.y = (this.player4.y - this.ball.height);
					this.ball.moveY = DIRECTION.UP;

				}
			}
			///////////////////////////////////////////////
		}

		// end
		if (distance <= 0) {
			this.over = true;
			if (team1score > team2score)
				setTimeout(function () { Pong2.endGameMenu('1. Csapat nyert!'); }, 1000);
			else if (team2score > team1score)
				setTimeout(function () { Pong2.endGameMenu('2. Csapat nyert!'); }, 1000);
			else
				setTimeout(function () { Pong2.endGameMenu('Döntetlen'); }, 1000);
		}
	},

	// Draw the objects to the canvas element
	draw: function () {
		// Clear the Canvas
		this.context.clearRect(
			0,
			0,
			this.canvas.width,
			this.canvas.height
		);

		// Set the fill style to black
		this.context.fillStyle = this.color;

		// Draw the background
		this.context.fillRect(
			0,
			0,
			this.canvas.width,
			this.canvas.height
		);

		// Set the fill style to white (For the player2s and the ball)
		this.context.fillStyle = '#ffffff';

		// Draw the player1
		this.context.fillRect(
			this.player1.x,
			this.player1.y,
			this.player1.width,
			this.player1.height
		);

		// Draw the player2
		this.context.fillRect(
			this.player2.x,
			this.player2.y,
			this.player2.width,
			this.player2.height
		);
		/////////////////////////////////////////////
		// Draw the player3
		this.context.fillRect(
			this.player3.x,
			this.player3.y,
			this.player3.width,
			this.player3.height
		);
		// Draw the player3
		this.context.fillRect(
			this.player4.x,
			this.player4.y,
			this.player4.width,
			this.player4.height
		);
		////////////////////////////////////

		// Draw the Ball
		if (Pong2._turnDelayIsOver.call(this)) {
			this.context.fillRect(
				this.ball.x,
				this.ball.y,
				this.ball.width,
				this.ball.height
			);
		}

		// Set the default canvas font and align it to the center
		this.context.font = '100px Courier New';
		this.context.textAlign = 'center';

		// Draw the player1s score (left)
		this.context.fillText(
			team1score + 't1',
			(this.canvas.width / 2) - 400,
			400
		);

		// Draw the player2s score (right)
		this.context.fillText(
			team2score + 't2',
			(this.canvas.width / 2) + 400,
			700
		);

		// Change the font size for the center score text
		this.context.font = '50px Courier New';

		// Draw the winning score (center)
		var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
		var seconds = Math.floor((distance % (1000 * 60)) / 1000);
		
		this.context.fillText(
			distance === 0 ? "0:0" : "0" + minutes + ":" + seconds,
			(this.canvas.width / 2),
			35
		);

		// Change the font size for the center score value
		this.context.font = '40px Courier';

		// Draw the current round number
		this.context.fillText(
			rounds[Pong2.round] ? rounds[Pong2.round] : rounds[Pong2.round - 1],
			(this.canvas.width / 2),
			100
		);
	},

	loop: function () {
		Pong2.update();
		//visszaszámlálás
		var now = new Date().getTime();
		distance = sixmin - now;
		Pong2.draw();

		// If the game is not over, draw the next frame.
		if (!Pong2.over) requestAnimationFrame(Pong2.loop);
	},

	listen: function () {
		document.addEventListener('keydown', function (key) {
			// Handle the 'Press any key to begin' function and start the game.
			if (Pong2.running === false) {
				Pong2.running = true;
				window.requestAnimationFrame(Pong2.loop);
				//időlimit
				sixmin = new Date(new Date().getTime() + (1 * 60 *1000));
			}

			//player1
			// Handle up arrow and up key events
			if (key.keyCode === 38) {
				key.preventDefault();
				Pong2.player1.move = DIRECTION.UP
			}
			// Handle down arrow and down key events
			if (key.keyCode === 40) {
				key.preventDefault();
				Pong2.player1.move = DIRECTION.DOWN;
			}
			//player2
			// Handle up arrow and w key events
			if (key.keyCode === 73) {
				key.preventDefault();
				Pong2.player2.move = DIRECTION.UP;
			}
			// Handle down arrow and s key events
			if (key.keyCode === 75) {
				key.preventDefault();
				Pong2.player2.move = DIRECTION.DOWN;
			}
			
			////////////////////////////////////////////////////
			//player3
			// Handle a key events
			if (key.keyCode === 65 ) Pong2.player3.move = DIRECTION.LEFT;
			// Handle d key events
			if (key.keyCode === 68 ) Pong2.player3.move = DIRECTION.RIGHT;
			
			//player4
			// Handle 4 key events
			if (key.keyCode === 100 ) Pong2.player4.move = DIRECTION.LEFT;
			// Handle 6 key events
			if (key.keyCode === 102 ) Pong2.player4.move = DIRECTION.RIGHT;
			/////////////////////////////
		});

		// Stop the player1 from moving when there are no keys being pressed.
		document.addEventListener('keyup', function (key) { Pong2.player1.move = DIRECTION.IDLE; });
		///////////////////////////////////////////
		document.addEventListener('keyup', function (key) { Pong2.player3.move = DIRECTION.IDLE; });
		document.addEventListener('keyup', function (key) { Pong2.player4.move = DIRECTION.IDLE; });
		////////////////////////////////////////////
	},

	// Reset the ball location, the player1 turns and set a delay before the next round begins.
	_resetTurn: function(victor) {
		this.ball = Ball.new.call(this, this.ball.speed);
		switch (victor){
			case this.player1: 
				this.turn = this.player2;
				team1score++;
				break;
			case this.player2: 
				this.turn = this.player1;
				team1score++;
				break;
			case this.player3: 
				this.turn = this.player4;
				team2score++;
				break;
			case this.player4: 
				this.turn = this.player3;
				team2score++;
				break;
		}
		this.timer = (new Date()).getTime();
	},

	// Wait for a delay to have passed after each turn.
	_turnDelayIsOver: function() {
		return ((new Date()).getTime() - this.timer >= 1000);
	},

	// Select a random color as the background of each level/round.
	_generateRoundColor: function () {
		var newColor = colors[Math.floor(Math.random() * colors.length)];
		if (newColor === this.color) return Pong2._generateRoundColor();
		return newColor;
	}
};

var Pong2 = Object.assign({}, Game2);
function team() {
	Pong2.initialize();
}