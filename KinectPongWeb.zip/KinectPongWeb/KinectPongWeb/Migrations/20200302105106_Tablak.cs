﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace KinectPongWeb.Migrations
{
    public partial class Tablak : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Players");

            migrationBuilder.AddColumn<string>(
                name: "Nev",
                table: "AspNetUsers",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "ResztvettJateks",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Jatekos = table.Column<string>(nullable: true),
                    Jatek = table.Column<string>(nullable: true),
                    Pontszam = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ResztvettJateks", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "ResztvettJateks");

            migrationBuilder.DropColumn(
                name: "Nev",
                table: "AspNetUsers");

            migrationBuilder.CreateTable(
                name: "Players",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("MySql:ValueGenerationStrategy", MySqlValueGenerationStrategy.IdentityColumn),
                    Email = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    Felhasznalonev = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    jelszo = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true),
                    nev = table.Column<string>(type: "longtext CHARACTER SET utf8mb4", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Players", x => x.Id);
                });
        }
    }
}
