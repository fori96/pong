﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace KinectPongWeb.Migrations
{
    public partial class MukodjPontszamMentes : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Pontszam",
                table: "Games",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Pontszam",
                table: "Games");
        }
    }
}
