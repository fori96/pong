﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KinectPongWeb.Models
{
    public class Player
    {
        public int Id { get; set; }
        public string Felhasznalonev { get; set; }
        public string Jelszo { get; set; }
        public string Nev { get; set; }
        public string Email { get; set; }
    }
}
