﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KinectPongWeb.Models
{
    public class ResztvettJatek
    {
        public int Id { get; set; }
        public string Jatekos { get; set; }
        public string Jatek { get; set; }
        public int Pontszam { get; set; }
    }
}
