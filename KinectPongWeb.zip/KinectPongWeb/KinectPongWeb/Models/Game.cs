﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace KinectPongWeb.Models
{
    public class Game
    {
        public string Id { get; set; }
        public string Idopont { get; set; }
        public string Tipus { get; set; }
        public string Nyertes { get; set; }
        public int Pontszam { get; set; }
    }
}
