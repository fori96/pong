﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KinectPongWeb.Data;
using KinectPongWeb.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.Extensions.Logging;

namespace KinectPongWeb.Pages
{
    [AllowAnonymous]
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;
        private readonly ApplicationDbContext _db;

        public IndexModel(ILogger<IndexModel> logger, ApplicationDbContext db)
        {
            _logger = logger;
            _db = db;
        }

        public void OnGet()
        {

        }

        public async Task<IActionResult> Save(int score)
        {
            if(score == null)
            {
                Console.WriteLine("fasz");
            }

            Game g = new Game()
            {
                Id = DateTime.Today.ToString() + DateTime.Now.Minute,
                Idopont = DateTime.Now.ToString(),
                Tipus = "vsAI",
                Nyertes = "Xx_Noobmaster69_xX",
                Pontszam = score
            };

            _db.Games.Add(g);
            await _db.SaveChangesAsync();

            return RedirectToAction("Index");
        }
    }
}
