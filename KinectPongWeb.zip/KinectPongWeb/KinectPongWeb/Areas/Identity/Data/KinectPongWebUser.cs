﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using KinectPongWeb.Data;
using Microsoft.AspNetCore.Identity;

namespace KinectPongWeb.Areas.Identity.Data
{
    // Add profile data for application users by adding properties to the KinectPongWebUser class
    public class KinectPongWebUser : IdentityUser
    {
        public virtual ICollection<ApplicationUserClaim> Claims { get; set; }
        public virtual ICollection<ApplicationUserLogin> Logins { get; set; }
        public virtual ICollection<ApplicationUserToken> Tokens { get; set; }
        public virtual ICollection<ApplicationUserRole> UserRoles { get; set; }

        public string Nev { get; set; }
    }
}
